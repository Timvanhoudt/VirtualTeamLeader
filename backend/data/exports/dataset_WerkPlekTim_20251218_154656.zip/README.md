# Training Dataset - WerkPlekTim

## Dataset Informatie

- **Werkplek:** WerkPlekTim
- **Beschrijving:** Geen beschrijving
- **Items:** Borstel
- **Totaal Images:** 8
- **Training Images:** 5
- **Validation Images:** 3
- **Split:** 80% train / 19% val
- **Gegenereerd:** 2025-12-18 15:46:56

## Class Distributie

- **NOK-Borstel**: 7 images (train: 5, val: 2)
- **OK**: 1 images (train: 0, val: 1)

## Structuur

```
dataset/
├── data.yaml          # YOLO config
├── train/
│   ├── ok/
│   ├── nok_hamer_weg/
│   └── ...
└── val/
    ├── ok/
    ├── nok_hamer_weg/
    └── ...
```

## Training in Google Colab

```python
from ultralytics import YOLO

# Load a model
model = YOLO('yolov8n-cls.pt')  # pretrained model

# Train the model
results = model.train(
    data='.',
    epochs=50,
    imgsz=640,
    batch=16,
    name='werkplek_classifier'
)

# Validate
metrics = model.val()

# Export
model.export(format='torchscript')
```

## Download Trained Model

Na training, download het beste model:
- `runs/classify/werkplek_classifier/weights/best.pt`

Upload dit bestand in het Admin Dashboard onder "Modellen".
